package com.example.projeto_mvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoMvcApplication.class, args);
	}

}
