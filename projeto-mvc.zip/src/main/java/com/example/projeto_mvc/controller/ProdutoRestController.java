package com.example.projeto_mvc.controller;

import com.example.projeto_mvc.model.Produto;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProdutoRestController {

    @GetMapping("/api/produto")
    public Produto getProduto() {
        return new Produto(1L, "Laptop", 2500.00);
    }

}
