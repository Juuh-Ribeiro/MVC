package com.example.projeto_mvc.controller;

import com.example.projeto_mvc.model.Produto;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;


@Controller
public class ProdutoViewController {

    @GetMapping("/produto")
    public String getProdutoView(Model model) {
        Produto produto = new Produto(1L, "Notebook", 2500.00);
        model.addAttribute("produto", produto);
        return "produto";
    }
    

}
